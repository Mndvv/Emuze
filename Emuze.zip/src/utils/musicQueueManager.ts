import { DisTube, DisTubeEvents, Queue, Song } from 'distube';
import { Client, TextChannel, ChatInputCommandInteraction, GuildMember, VoiceBasedChannel } from 'discord.js';
import { SpotifyPlugin } from '@distube/spotify';
import { SoundCloudPlugin } from '@distube/soundcloud';
import { YtDlpPlugin } from '@distube/yt-dlp';
import YTMusic from 'ytmusic-api';
import { CustomClient } from '../types';

class MusicQueueManager {
  private distube: DisTube;
  private ytmusic: YTMusic;

  constructor(client: CustomClient) {
    // Initialize YTMusic once during construction
    this.ytmusic = new YTMusic();
    this.ytmusic.initialize().catch(console.error);

    this.distube = new DisTube(client, {
      plugins: [
        new SpotifyPlugin(),
        new SoundCloudPlugin(),
        new YtDlpPlugin({
          update: true // Keep yt-dlp updated
        })
      ],
      savePreviousSongs: true,
      nsfw: false,
    });

    this.setupEventHandlers();
  }

  private setupEventHandlers(): void {
    this.distube
      .on('playSong' as keyof DisTubeEvents, async (queue: Queue, song: Song) => {
        try {
          const textChannel = queue.textChannel as TextChannel;
          if (textChannel?.id) {
            await textChannel.send(
              `▶️ Playing: \`${song.name}\` - \`${song.formattedDuration}\`\nRequested by: ${song.user?.tag}`
            );
          }
        } catch (error) {
          console.error('Error in playSong event:', error);
        }
      })
      .on('addSong' as keyof DisTubeEvents, async (queue: Queue, song: Song) => {
        try {
          const textChannel = queue.textChannel as TextChannel;
          if (textChannel?.id) {
            await textChannel.send(
              `📝 Added \`${song.name}\` - \`${song.formattedDuration}\` to the queue`
            );
          }
        } catch (error) {
          console.error('Error in addSong event:', error);
        }
      })
      .on('error' as keyof DisTubeEvents, async (error: Error, queue: Queue) => {
        try {
          const textChannel = queue.textChannel as TextChannel;
          if (textChannel?.id) {
            const errorMessage = `❌ Error: ${error.message}`;
            await textChannel.send(errorMessage.length > 2000 ? errorMessage.slice(0, 2000) : errorMessage);
          } else {
            console.error('Error event triggered but channel is not a TextChannel:', error);
          }
        } catch (error) {
          console.error('Error in error event handler:', error);
        }
      });
  }

  public async play(interaction: ChatInputCommandInteraction): Promise<void> {
    try {
      const member = interaction.member as GuildMember;
      const voiceChannel = member.voice?.channel as VoiceBasedChannel;

      if (!voiceChannel) {
        await interaction.reply({ content: '❌ You must be in a voice channel!', ephemeral: true });
        return;
      }

      const query = interaction.options.getString('query', true);

      try {
        // Play directly using DisTube's play method
        await this.distube.play(voiceChannel, query, {
          member: member,
          textChannel: interaction.channel as TextChannel,
          metadata: { interaction }
        });

        await interaction.reply('🎵 Request received! Processing your song...');
      } catch (error) {
        console.error('Error playing song:', error);
        if (!interaction.replied && !interaction.deferred) {
          await interaction.reply('❌ Failed to play the song. Please try again.');
        } else {
          await interaction.followUp('❌ Failed to play the song. Please try again.');
        }
      }
    } catch (error) {
      console.error('Play Error:', error);
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ An error occurred while processing your request.', ephemeral: true });
      } else {
        await interaction.followUp('❌ An error occurred while processing your request.');
      }
    }
  }

  public async skip(interaction: ChatInputCommandInteraction): Promise<void> {
    try {
      const queue = this.distube.getQueue(interaction.guildId!);
      if (!queue) {
        await interaction.reply({ content: '❌ No active queue!', ephemeral: true });
        return;
      }

      await queue.skip();
      await interaction.reply('⏭️ Skipped the current song!');
    } catch (error) {
      console.error('Skip Error:', error);
      await interaction.reply({ content: '❌ Failed to skip the song.', ephemeral: true });
    }
  }

  public async stop(interaction: ChatInputCommandInteraction): Promise<void> {
    try {
      const queue = this.distube.getQueue(interaction.guildId!);
      if (!queue) {
        await interaction.reply({ content: '❌ No active queue!', ephemeral: true });
        return;
      }

      await queue.stop();
      await interaction.reply('⏹️ Stopped the music and cleared the queue!');
    } catch (error) {
      console.error('Stop Error:', error);
      await interaction.reply({ content: '❌ Failed to stop the music.', ephemeral: true });
    }
  }
}

export default MusicQueueManager;

export function getMusicQueueManager(client: CustomClient): MusicQueueManager {
  return new MusicQueueManager(client);
}